package guang.crawler.crawlWorker.parser;

public interface ParseData
{

	@Override
	public String toString();

}

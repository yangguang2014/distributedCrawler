package guang.crawler.siteManager.docid;

public class DocidServer
{
	private int	id;
	
	public int next()
	{
		return this.id++;
	}
	
}

package guang.crawler.commons.parserData;

public interface ParseData
{

	@Override
	public String toString();

}

package guang.crawler.commons.service;

public enum SiteStatus {
	enabled, disabled, running, notexist, error
}

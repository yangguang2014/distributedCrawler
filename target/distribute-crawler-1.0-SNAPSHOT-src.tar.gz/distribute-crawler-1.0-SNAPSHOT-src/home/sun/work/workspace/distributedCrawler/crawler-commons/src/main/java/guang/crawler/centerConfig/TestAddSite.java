package guang.crawler.centerConfig;

import guang.crawler.centerConfig.sitesConfig.SiteInfo;
import guang.crawler.commons.service.WebGatherNodeBean;

import java.io.IOException;

import org.apache.zookeeper.KeeperException;

public class TestAddSite {
	
	public static void main(final String[] args) throws InterruptedException,
	        IOException, KeeperException {
		// SiteInfo siteInfo = CenterConfig.me()
		// .init("ubuntu-3,ubuntu-6,ubuntu-8").getSitesConfigInfo()
		// .getSitesInfo().registSite("site1");
		// WebGatherNodeBean configBean = new WebGatherNodeBean();
		// configBean.setWgnEntryUrl("http://www.quanben.com/");
		// siteInfo.setWebGatherNodeInfo(configBean, false);
		// siteInfo.setHandled(false, false);
		// siteInfo.update();
		
		WebGatherNodeBean bean = new WebGatherNodeBean();
		bean.setId(1l);
		bean.setWgnEntryUrl("http://news.qq.com/a/20140630/050346.htm");
		
		SiteInfo siteInfo = CenterConfig.me()
		                                .init("ubuntu-3,ubuntu-6,ubuntu-8")
		                                .getSitesConfigInfo()
		                                .getSitesInfo()
		                                .registSite("testSite001");
		siteInfo.setWebGatherNodeInfo(bean, false)
		        .setEnabled(true)
		        .setFinished(false, false)
		        .setHandled(false, false)
		        .update();
	}
}

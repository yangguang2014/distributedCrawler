package guang.crawler.launcher;

import java.io.IOException;

public class Test {
	public static void main(final String[] args) throws IOException,
	        InterruptedException, ClassNotFoundException {
		// 既然是模拟，设置一下环境变量
		System.setProperty("crawler.home",
		                   System.getProperty("user.home")
		                           + "/work/workspace/distributedCrawler/target/distribute-crawler-1.0-SNAPSHOT-release");
		CrawlerLauncherMain.main(args);
	}
}

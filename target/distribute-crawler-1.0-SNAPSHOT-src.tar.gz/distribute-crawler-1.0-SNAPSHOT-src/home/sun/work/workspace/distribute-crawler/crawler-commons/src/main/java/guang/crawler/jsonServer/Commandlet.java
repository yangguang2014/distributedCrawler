package guang.crawler.jsonServer;


public interface Commandlet
{
	public DataPacket doCommand(DataPacket request);
	
}

package guang.crawler.controller;

public enum SiteStatus {

}

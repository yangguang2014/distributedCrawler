package guang.crawler.siteManager.jobQueue;

public interface Sync
{
	public void sync();
}
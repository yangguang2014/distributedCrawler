package guang.crawler.centerController;

import guang.crawler.connector.CenterConfigConnector;

public class ControllerManagerInfo extends CenterConfigElement {

	public ControllerManagerInfo(String path,
			CenterConfigConnector connector) {
		super(path, connector);
	}

	private static final String KEY_CONTROLLER_MANAGER_ADDR="controller.manager.address";
	
	public String getControllerManagerAddress() throws InterruptedException{
		return this.get(KEY_CONTROLLER_MANAGER_ADDR, true);
	}
	
	public void setControllerManagerAddress(String address) throws InterruptedException{
		this.put(KEY_CONTROLLER_MANAGER_ADDR, address, true);
	}
}

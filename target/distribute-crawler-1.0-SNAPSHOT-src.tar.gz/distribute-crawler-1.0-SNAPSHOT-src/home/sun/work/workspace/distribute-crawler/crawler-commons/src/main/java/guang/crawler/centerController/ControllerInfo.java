package guang.crawler.centerController;

import guang.crawler.connector.CenterConfigConnector;

import org.apache.zookeeper.CreateMode;

public class ControllerInfo extends CenterConfigElement {

	private ControllerManagerInfo controllerManagerInfo;
	public ControllerInfo(String path, CenterConfigConnector connector) {
		super(path, connector);
	}
	
	/**
	 * 竞争作为控制器
	 * @param addr
	 * @return
	 * @throws InterruptedException
	 */
	public boolean competeForController(String addr) throws InterruptedException{
		String realPath=this.connector.createNode(path+"/manager", CreateMode.EPHEMERAL, "manager of the controller".getBytes());
		if(realPath!=null){
			this.controllerManagerInfo=new ControllerManagerInfo(realPath, connector);
			this.controllerManagerInfo.setControllerManagerAddress(addr);
			return true;
		}
		return false;
	}

	/**
	 * 获取控制器的管理者信息
	 * @return
	 */
	public ControllerManagerInfo getControllerManagerInfo() {
		return controllerManagerInfo;
	}
	
	
	
}

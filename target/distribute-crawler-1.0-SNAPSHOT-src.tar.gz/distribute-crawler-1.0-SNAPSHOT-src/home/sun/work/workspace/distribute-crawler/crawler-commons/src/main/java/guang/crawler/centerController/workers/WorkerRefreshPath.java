package guang.crawler.centerController.workers;

import guang.crawler.centerController.CenterConfigElement;
import guang.crawler.connector.CenterConfigConnector;

public class WorkerRefreshPath extends CenterConfigElement {

	public WorkerRefreshPath(String path, CenterConfigConnector connector) {
		super(path, connector);
	}

}
